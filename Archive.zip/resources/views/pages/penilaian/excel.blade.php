<?php
$judul = 'LAPORAN PENILAIAN DOSEN '.strtoupper($semester->nama).' TAHUN '.strtoupper($semester->tahun);
// header("Content-type: application/vnd-ms-excel");
// header("Content-Disposition: attachment; filename=".str_replace(' ','_',$judul).'_'.time().".xls");
?>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
         body{
              font-size:11px;
         }
    </style>
</head>
<body>
<table class="table table-borderless">
     <tr>
          <td colspan="7" style="font-weight:600;text-align:center">{{ $judul }}</td>
     </tr>
</table>
<br><br>
<table border=".5pt">
     <thead>
          <tr>
               <th rowspan="2" style="text-align: center;">No</th>
               <th rowspan="2" style="text-align: center;">Dosen</th>
               @if(Auth::user()->roles == 'admin')
               <th rowspan="2" style="text-align: center;">Prodi</th>
               @endif
               <th colspan="4" style="text-align: center;">Penilaian</th>
          </tr>
          <tr>
               <th style="text-align: center;">Sangat Baik</th>
               <th style="text-align: center;">Baik</th>
               <th style="text-align: center;">Cukup</th>
               <th style="text-align: center;">Kurang</th>
          </tr>
     </thead>
     <tbody>
          @if($data !=  null)
          @foreach($data as $key => $val)
               <tr>
                    <td>
                         {{$key+1}}
                    </td>
                    <td>
                         {{ $val['nama'] }}
                    </td>
                    @if(Auth::user()->roles == 'admin')
                         <td style="text-align: center;">{{ $val['prodi'] }}</td>
                    @endif
                    <td style="text-align: center;">{{ $val['Sangat Baik'] }}</td>
                    <td style="text-align: center;">{{ $val['Baik'] }}</td>
                    <td style="text-align: center;">{{ $val['Cukup'] }}</td>
                    <td style="text-align: center;">{{ $val['Kurang'] }}</td>
               </tr>
          @endforeach
         @else
         <td  style="text-align: center;" colspan="{{ (Auth::user()->roles == 'admin'?7:6) }}">
              Data Tidak Ditemukan
         </td>
         @endif
     </tbody>
</table>