<footer class="main-footer">
     <div class="footer-left">
     Copyright &copy; 2022 <div class="bullet"></div> SiMonik (Sistem Monitoring Perkuliahan).
    
     </div>
     <div class="footer-right">
          <a href="https://www.uho.ac.id/" target="Blank">
               Universitas Halu Oleo
          </a> 
     </div>
</footer>